import tkinter as tk
from tkinter import messagebox

def show_msg():
    message = entry.get()
    messagebox.showinfo("Message", message)

root = tk.Tk()
root.title("Show Message")
root.geometry("300x200")
root.configure(bg="white")

label_message = tk.Label(root, text="Enter your message:", bg="white", font=("Arial", 12))
label_message.pack()

entry = tk.Entry(root, bg="white", font=("Arial", 12))
entry.pack()

button = tk.Button(root, text="Show Message", command=show_msg, bg="blue", font=("Arial", 12))
button.pack()

# Bind enter key to button
root.bind('<Return>', lambda event: button.invoke())

root.mainloop()